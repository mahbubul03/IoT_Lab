/*
  ============================================================
  ECG Reader - DFRobot/Gravity SEN0213 (AD8232) on ESP32-S3 N16R8
  ============================================================
  Board:   Gravity Analog Heart Rate Monitor Sensor (AD8232)
  Wiring:  Signal Output -> GPIO 4 (ADC1 channel; safe with WiFi/BLE
           because ADC1 is not shared with the radio like ADC2).

  This board variant has no LO+/LO- leads-off pins broken out, so
  firmware cannot flag "electrodes not attached". A flat / railed
  signal on the host side means poor electrode contact instead.

  --------------------------------------------------------------
  WHAT CHANGED vs the original sketch (accuracy fixes)
  --------------------------------------------------------------
  1) CALIBRATED VOLTAGE, NOT RAW COUNTS.
     The ESP32-S3 ADC is markedly non-linear and its raw counts do
     NOT map linearly to volts (worst near the rails). We now use
     analogReadMilliVolts(), which applies the chip's factory eFuse
     calibration and returns a linearized voltage. This is the single
     biggest accuracy improvement over sending raw analogRead() codes.

  2) FULL 12-bit SAMPLING (not throttled to 10-bit).
     Native ADC resolution is used; the value we transmit is a
     calibrated voltage, so the host no longer depends on raw code
     width at all.

  3) 250 Hz SAMPLE RATE (was 200 Hz).
     250 Hz is a common clinical ECG rate and gives 4 ms timing
     resolution, which sharpens R-peak localisation and therefore
     R-R interval / HRV accuracy on the host.

  4) OUTPUT IN TENTHS OF A MILLIVOLT (integer).
     We average OVERSAMPLE_COUNT calibrated reads as a float and send
     round(mV * 10). This keeps the benefit of oversampling (sub-mV
     resolution) while staying integer-only and cheap to parse.
     The AD8232's ~1.65 V output bias is left in; the host high-pass
     filter removes it.

  Output format (one value per line):
      <tenths_of_millivolt>       e.g. 16523  == 1652.3 mV

  Keep FS_HZ here in sync with FS in the Python plotter.

  NOTE: Hobbyist/research tool, NOT a certified medical device.
  Do not use it for diagnosis or clinical decisions.
  ============================================================
*/

const int ecgPin = 4;

// 250 Hz -> 4000 us. MUST match FS (250.0) in the Python plotter.
const unsigned long SAMPLE_INTERVAL_US = 4000UL;
unsigned long nextSampleTime = 0;

// Plain hardware oversampling to knock down the few LSBs of ADC noise.
// Each analogReadMilliVolts() takes roughly 100-200 us, so 8 reads fit
// comfortably inside the 4 ms budget.
const int OVERSAMPLE_COUNT = 8;

void setup() {
  Serial.begin(115200);

  analogReadResolution(12);        // native 12-bit; mV output is calibrated
  analogSetAttenuation(ADC_11db);  // full ~0-3.3V range; AD8232 rides ~1.65V

  // Prime the ADC so the first transmitted sample isn't a cold read.
  for (int i = 0; i < OVERSAMPLE_COUNT; i++) {
    analogReadMilliVolts(ecgPin);
  }

  nextSampleTime = micros();
}

void loop() {
  unsigned long now = micros();

  // (long) cast on the unsigned difference handles micros() rollover.
  if ((long)(now - nextSampleTime) >= 0) {
    uint32_t sum = 0;
    for (int i = 0; i < OVERSAMPLE_COUNT; i++) {
      sum += analogReadMilliVolts(ecgPin);   // calibrated millivolts
    }
    float mV = (float)sum / OVERSAMPLE_COUNT;

    // Send tenths of a millivolt as an integer (preserves oversampling).
    Serial.println((int)(mV * 10.0f + 0.5f));

    nextSampleTime += SAMPLE_INTERVAL_US;

    // If we fell behind (e.g. Serial stalled), resync to "now" rather
    // than firing a catch-up burst that would corrupt the fixed-rate
    // timing the host filters and R-R detection depend on.
    if ((long)(now - nextSampleTime) > 0) {
      nextSampleTime = now + SAMPLE_INTERVAL_US;
    }
  }
}

# ECG Monitor - ESP32-S3 + AD8232 (SEN0213)

A hobbyist/research ECG acquisition + live-analysis tool. The ESP32-S3
streams **calibrated** ECG voltage over serial; a Python host filters it,
detects R-peaks with a Pan-Tompkins style QRS detector, computes heart
rate from validated R-R intervals, and draws a true ECG-paper-style graph.

> **Not a medical device.** Do not use for diagnosis or clinical decisions.

## Files
- `ecg_firmware/ecg_firmware.ino` - ESP32-S3 firmware (Arduino).
- `ecg_plotter.py` - live plotter + QRS/R-R analysis.
- `requirements.txt` - Python dependencies.

## Quick start
```bash
pip install -r requirements.txt

# validate the whole pipeline with NO hardware:
python ecg_plotter.py --simulate --bpm 75

# real sensor:
python ecg_plotter.py --port COM5 --mains 50      # 50 for EU/Asia, 60 for NA
```

## Wiring
AD8232 **Signal Output -> GPIO 4** (ADC1). Use ADC1 pins so WiFi/BLE stays
usable. This board variant has no LO+/LO- pins, so leads-off is detected on
the host as a flat/railed trace (shown as a `CHECK ELECTRODES` warning).

## What was fixed and why

### Firmware (accuracy)
1. **Calibrated millivolts instead of raw ADC counts.** The ESP32-S3 ADC is
   strongly non-linear; raw `analogRead()` codes don't map linearly to volts.
   `analogReadMilliVolts()` applies the chip's factory eFuse calibration.
   This is the biggest single accuracy gain.
2. **Full 12-bit sampling** (was throttled to 10-bit, discarding 2 bits).
3. **250 Hz** sample rate (was 200 Hz) for sharper R-peak timing / HRV.
4. Output is **tenths of a millivolt** (integer) so oversampling still buys
   sub-mV resolution while staying cheap to parse.

### Python (DSP + detection)
1. **Correct filter initial conditions.** Bandpass and notch states are now
   scaled by the first sample (`zi * x0`), removing the large startup
   transient that previously corrupted the first BPM readings. The notch
   state uses `lfilter_zi` instead of plain zeros.
2. **Batched, stateful filtering** of each incoming chunk (faster, and the
   `lfilter` import no longer happens per sample).
3. **Pan-Tompkins style QRS detection**: derivative -> squaring ->
   150 ms moving-window integration -> adaptive threshold -> 300 ms
   refractory -> refine each candidate to the true R location. This replaces
   the old `std * 1.2` threshold that mistook T-waves and noise for beats.
4. **Physiological R-R validation**: only 0.30-2.0 s intervals (30-200 BPM)
   are kept; BPM is the **median** of recent intervals (robust to a single
   missed/extra beat) instead of the mean of everything. HRV (**RMSSD**) is
   also reported.
5. **True ECG graph**: x-axis in seconds with a 0.2 s / 0.04 s grid, y-axis
   in millivolts with a 0.5 mV / 0.1 mV grid, and detected R-peaks marked.
6. **Signal-quality warnings** for flat (poor contact) or railed signals.
7. No more zero-prefilled buffers faking a flat trace before data arrives.

## Clinical-style report

The plotter is laid out like a hospital ECG cart:

- **Raw strip** - unfiltered sensor output.
- **Rhythm strip** - filtered ECG on ECG-paper grid (0.2 s big / 0.04 s
  small squares) with each detected **R-peak** marked; QRS polarity is
  auto-corrected so R-waves always point up.
- **Representative beat** - the ensemble **median of recent beats** (this is
  what cancels noise so the small P and T waves become measurable on a single
  lead), with **P, Q, R, S, T, U** labelled and the isoelectric baseline drawn.
- **Measurement header** - HR, R-R, PR, QRS, QT/QTc and a short
  rate/regularity read-out.

Formulas: **HR = 60 / RR** (same as 300 / number of large squares) and
**QTc = QT / sqrt(RR)** (Bazett). Adult reference ranges: PR 120-200 ms,
QRS < 120 ms, QTc < 450 ms (M) / 460 ms (F), rate 60-100 bpm. The header
flags long PR / wide QRS / long QTc when thresholds are exceeded.

## Notes / limitations
- Amplitude is the AD8232 **output** voltage (module has its own fixed gain),
  not clinical lead millivolts, so the mV axis is relative, not diagnostic.
- Keep `FS` in `ecg_plotter.py` equal to the firmware sample rate.
- Good electrode contact and skin prep matter more than any filter; a noisy
  or railed trace usually means the electrodes, not the code.

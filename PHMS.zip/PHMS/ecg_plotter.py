#!/usr/bin/env python3
"""
============================================================
ECG Live Plotter - ESP32-S3 + AD8232 (SEN0213)
============================================================
Reads calibrated ECG values (integer tenths-of-millivolt, one per
line) streamed at a fixed 250 Hz from the matching firmware, applies
a bandpass + notch filter, detects R-peaks with a Pan-Tompkins style
QRS detector, and produces a clinical-style report:

  * Raw signal strip
  * Filtered rhythm strip on ECG paper (0.2 s / 0.04 s grid) with
    R-peaks marked
  * A representative (ensemble-median) beat with P, Q, R, S, T, U
    labelled and the isoelectric baseline drawn
  * A measurement header: HR, R-R, PR, QRS, QT/QTc (Bazett) and a
    short rate/regularity read-out

Formulas used:
  * Heart rate    HR   = 60 / RR(s)               (= 300 / large squares)
  * Corrected QT  QTc  = QT / sqrt(RR)            (Bazett)
Reference intervals (adult): PR 120-200 ms, QRS < 120 ms,
QTc < 450 ms (M) / < 460 ms (F), rate 60-100 bpm.

Fs = 250 Hz is baked into the filter and detector design. If you
change SAMPLE_INTERVAL_US in the firmware, update FS here to match.

Usage:
    python ecg_plotter.py --port COM5
    python ecg_plotter.py --port /dev/ttyUSB0 --seconds 6 --mains 50
    python ecg_plotter.py --simulate --bpm 75          # no hardware needed

Options:
    --port      Serial port (required unless --simulate)
    --baud      Baud rate (default 115200, matches firmware)
    --seconds   Seconds of ECG visible in the plot (default 10.0; raise it
                for a longer window, e.g. --seconds 20)
    --mains     Mains hum to notch out: 50 or 60 (default 50)
    --raw-only  Skip filtering / detection, plot raw signal only
    --simulate  Generate a synthetic ECG instead of reading serial
    --bpm       Heart rate for --simulate (default 72)

NOTE: Hobbyist/research tool, NOT a certified medical device.
Do not use for diagnosis or clinical decisions.
============================================================
"""

import argparse
import sys
import time
from collections import deque

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.ticker import MultipleLocator, FuncFormatter
from scipy.signal import butter, sosfilt, sosfilt_zi, iirnotch, lfilter, lfilter_zi, find_peaks

FS = 250.0            # Hz - must match the firmware sample rate
MV_PER_UNIT = 0.1     # firmware sends tenths of a millivolt


# --------------------------------------------------------------------------
# Filtering
# --------------------------------------------------------------------------
def build_filters(mains_hz: float):
    """0.5-40 Hz bandpass isolates the diagnostic ECG band and removes
    baseline wander + high-frequency noise; an IIR notch removes mains hum.

    Both filters are returned with *unit* initial conditions; the caller
    scales them by the first real sample so the stream doesn't start with
    a large settling transient (a bug in the original: zi was used unscaled
    and the notch state was plain zeros)."""
    nyq = FS / 2.0
    # 2nd-order sections keep the very-low 0.5 Hz corner numerically stable.
    bp_sos = butter(2, [0.5 / nyq, 40.0 / nyq], btype="band", output="sos")
    bp_zi_unit = sosfilt_zi(bp_sos)

    notch_b, notch_a = iirnotch(mains_hz, Q=30, fs=FS)
    notch_zi_unit = lfilter_zi(notch_b, notch_a)

    return bp_sos, bp_zi_unit, notch_b, notch_a, notch_zi_unit


# --------------------------------------------------------------------------
# Pan-Tompkins style R-peak detection
# --------------------------------------------------------------------------
def detect_r_peaks(sig: np.ndarray, fs: float):
    """Detect R-peaks on an already band-passed ECG segment.

    Pipeline: derivative -> squaring -> moving-window integration ->
    adaptive threshold -> peak picking with a physiological refractory
    period -> refine each candidate to the true R location on the
    band-passed signal. Returns integer sample indices into `sig`.
    """
    n = len(sig)
    if n < int(fs * 0.5):
        return np.array([], dtype=int)

    # 1) Derivative emphasises the steep QRS slope.
    deriv = np.ediff1d(sig, to_begin=0.0)
    # 2) Square: all-positive, boosts large slopes.
    squared = deriv * deriv
    # 3) Moving-window integration (~150 ms) yields one hump per QRS.
    win = max(1, int(0.150 * fs))
    integ = np.convolve(squared, np.ones(win) / win, mode="same")

    # 4) Adaptive threshold from the integration signal's statistics.
    thr = np.mean(integ) + 0.5 * np.std(integ)
    if thr <= 0:
        return np.array([], dtype=int)

    # 5) Refractory ~300 ms -> reject anything faster than 200 BPM.
    min_dist = max(1, int(0.30 * fs))
    cand, _ = find_peaks(integ, height=thr, distance=min_dist)
    if cand.size == 0:
        return np.array([], dtype=int)

    # 6) The integration hump lags/blurs the true R; refine each candidate to
    #    the local peak on the band-passed signal. `sig` is expected to be
    #    polarity-corrected (R upright) by the caller, so we take the positive
    #    maximum, which puts the marker on the R-wave rather than a deep S.
    baseline = np.median(sig)
    search = max(1, int(0.05 * fs))
    r_idx = []
    for c in cand:
        a = max(0, c - search)
        b = min(n, c + search + 1)
        r_idx.append(a + int(np.argmax(sig[a:b] - baseline)))
    return np.unique(np.asarray(r_idx, dtype=int))


def heart_rate_from_peaks(r_idx: np.ndarray, fs: float):
    """Return (bpm, rmssd_ms, valid_rr_seconds) using only physiologically
    plausible R-R intervals (0.30-2.0 s == 30-200 BPM). BPM is the median
    of recent intervals, which is far more robust to a single missed or
    extra beat than the mean of everything (the original approach).

    Heart-rate formula: HR = 60 / RR(s) = 60000 / RR(ms), which is the same
    as the paper method HR = 300 / (number of 0.2 s large squares per beat)."""
    if r_idx.size < 2:
        return None, None, np.array([])
    rr = np.diff(r_idx) / fs
    rr = rr[(rr >= 0.30) & (rr <= 2.0)]
    if rr.size == 0:
        return None, None, rr
    bpm = 60.0 / np.median(rr[-12:])
    rmssd = None
    if rr.size >= 3:
        rmssd = np.sqrt(np.mean(np.diff(rr) ** 2)) * 1000.0  # ms
    return bpm, rmssd, rr


# --------------------------------------------------------------------------
# ECG wave delineation (P, Q, R, S, T, U + clinical intervals)
# --------------------------------------------------------------------------
def _walk_to_baseline(sig, start, baseline, thresh, direction):
    """Walk left (-1) or right (+1) from `start` until the signal comes back
    within `thresh` of `baseline`; used to find wave onsets/offsets."""
    i = int(start)
    n = len(sig)
    while 0 < i < n - 1 and abs(sig[i] - baseline) > thresh:
        i += direction
    return i


def delineate_beat(disp, r_idx, fs, rr_sec=None):
    """Build an ensemble-median 'representative beat' from the detected R-peaks
    and locate the P, Q, R, S, T and U fiducial points plus wave on/offsets.

    Averaging many beats aligned on R (what clinical carts do) cancels random
    noise, so the small P and T waves become measurable on a single lead.

    Physiological gates (adult single-lead):
      * PR onset-to-onset typically 120-200 ms - reject "P" closer than ~80 ms
      * QRS typically 60-120 ms
      * QT typically ~250-450 ms; search window uses Bazett expected QT
      * Label Q/S/P/T/U only when the deflection is real; otherwise leave None
        so the report shows "--" instead of a wrong number.
    """
    pre, post = int(0.30 * fs), int(0.50 * fs)
    beats = [disp[r - pre:r + post] for r in r_idx
             if r - pre >= 0 and r + post < len(disp)
             and not np.any(np.isnan(disp[r - pre:r + post]))]
    if len(beats) < 3:
        return None

    template = np.median(np.vstack(beats), axis=0)
    # ~16 ms smoothing for measurement - cancels residual ripple on AD8232.
    k = max(1, int(0.016 * fs) | 1)  # odd length
    tmpl = np.convolve(template, np.ones(k) / k, mode="same")

    n = len(tmpl)
    w = int(0.04 * fs)
    R = (pre - w) + int(np.argmax(tmpl[pre - w:pre + w + 1]))

    # Baseline from the isoelectric stretch well before R (TP/PR segment).
    b0, b1 = max(0, R - int(0.22 * fs)), max(1, R - int(0.12 * fs))
    baseline = float(np.median(tmpl[b0:b1])) if b1 > b0 else float(np.median(tmpl))
    r_amp = float(tmpl[R] - baseline)
    abs_r = max(abs(r_amp), 1e-6)

    # Q: only if a clear negative dip exists before R (else leave unlabeled).
    qw = int(0.05 * fs)
    q_region = tmpl[max(0, R - qw):R + 1]
    qi = int(np.argmin(q_region))
    Q_cand = max(0, R - qw) + qi
    Q = Q_cand if (tmpl[Q_cand] - baseline) < -0.05 * abs_r else None

    # S: clear negative after R (common); if absent leave unlabeled.
    s_region = tmpl[R:min(n, R + qw + 1)]
    si = int(np.argmin(s_region))
    S_cand = R + si
    S = S_cand if (tmpl[S_cand] - baseline) < -0.05 * abs_r else None

    # QRS onset / J-point from the steepest QRS edges, capped to ~40-120 ms.
    qrs_thr = max(0.12 * abs_r, 1e-6)
    start_on = Q if Q is not None else R
    start_off = S if S is not None else R
    qrs_on = _walk_to_baseline(tmpl, start_on, baseline, qrs_thr, -1)
    j_off = _walk_to_baseline(tmpl, start_off, baseline, qrs_thr, +1)
    # Cap QRS width to a physiological range so noise can't inflate QT later.
    if (j_off - qrs_on) / fs > 0.14:
        j_off = qrs_on + int(0.12 * fs)
    if (j_off - qrs_on) / fs < 0.04:
        j_off = min(n - 1, qrs_on + int(0.08 * fs))

    # ---- P wave ----------------------------------------------------------
    # Search 80-280 ms before QRS onset. Require a real peak (not QRS foot)
    # and a PR onset-to-onset of at least ~100 ms.
    P = p_on = p_off = None
    p0 = max(0, qrs_on - int(0.28 * fs))
    p1 = max(1, qrs_on - int(0.08 * fs))
    if p1 - p0 > int(0.04 * fs):
        seg = tmpl[p0:p1] - baseline
        # Prefer a positive P (common in lead II-like orientations).
        pi = int(np.argmax(seg))
        P_cand = p0 + pi
        p_amp = float(tmpl[P_cand] - baseline)
        if p_amp > 0.04 * abs_r:
            p_thr = max(0.25 * p_amp, 0.02 * abs_r)
            p_on_c = _walk_to_baseline(tmpl, P_cand, baseline, p_thr, -1)
            p_off_c = min(_walk_to_baseline(tmpl, P_cand, baseline, p_thr, +1), qrs_on)
            pr_ms = (qrs_on - p_on_c) / fs * 1000.0
            # Adult PR is almost never < 100 ms; reject near-QRS noise.
            if 100.0 <= pr_ms <= 300.0 and (p_off_c - p_on_c) / fs >= 0.04:
                P, p_on, p_off = P_cand, p_on_c, p_off_c

    # ---- T wave ----------------------------------------------------------
    # Expected QT ≈ 0.4 * sqrt(RR) (Bazett at QTc=400). Search around that,
    # never past ~0.50*RR or 450 ms from QRS onset.
    if rr_sec and rr_sec > 0:
        qt_exp = 0.40 * np.sqrt(rr_sec)
        t_lo = qrs_on + int(max(0.18, qt_exp - 0.10) * fs)
        t_hi = qrs_on + int(min(0.45, max(qt_exp + 0.08, 0.28), 0.50 * rr_sec) * fs)
    else:
        t_lo = qrs_on + int(0.18 * fs)
        t_hi = qrs_on + int(0.42 * fs)
    t_lo = max(t_lo, j_off + int(0.04 * fs))
    t_hi = min(n, max(t_lo + 3, t_hi))

    T = t_off = None
    if t_hi - t_lo > 3:
        T = t_lo + int(np.argmax(np.abs(tmpl[t_lo:t_hi] - baseline)))
        t_amp = abs(tmpl[T] - baseline)
        if t_amp > 0.05 * abs_r:
            t_thr = max(0.20 * t_amp, 0.03 * abs_r)
            t_off_c = _walk_to_baseline(tmpl, T, baseline, t_thr, +1)
            # Hard cap: QT must stay inside a physiological band.
            qt_ms = (t_off_c - qrs_on) / fs * 1000.0
            qt_max = (0.50 * rr_sec * 1000.0) if rr_sec else 450.0
            qt_max = min(qt_max, 460.0)
            if qt_ms > qt_max:
                t_off_c = qrs_on + int(qt_max / 1000.0 * fs)
            if 220.0 <= (t_off_c - qrs_on) / fs * 1000.0 <= qt_max:
                t_off = min(t_off_c, n - 1)
            else:
                T = None
        else:
            T = None

    # ---- U wave (optional, often absent) ---------------------------------
    U = None
    if t_off is not None:
        u0, u1 = min(n - 1, t_off + int(0.02 * fs)), min(n, t_off + int(0.14 * fs))
        if u1 - u0 > 3:
            ui = u0 + int(np.argmax(tmpl[u0:u1] - baseline))
            if (tmpl[ui] - baseline) > 0.08 * abs_r:
                U = ui

    return dict(template=tmpl, baseline=baseline, dt=1.0 / fs, r_pos=R,
                P=P, Q=Q, R=R, S=S, T=T, U=U,
                p_on=p_on, qrs_on=qrs_on, j_off=j_off, t_off=t_off)


def clinical_intervals(fid, rr_sec):
    """Turn delineation fiducials + mean R-R into clinical intervals (ms) and a
    Bazett-corrected QT. Returns a dict of floats/None.

    HR = 60 / RR(s).  QTc = QT / sqrt(RR)  (Bazett).
    Intervals outside adult physiological bands are dropped to None so the
    report shows "--" rather than a misleading value."""
    fs = 1.0 / fid["dt"]
    def ms(a, b):
        return (b - a) / fs * 1000.0 if (a is not None and b is not None) else None
    pr = ms(fid["p_on"], fid["qrs_on"])
    qrs = ms(fid["qrs_on"], fid["j_off"])
    qt = ms(fid["qrs_on"], fid["t_off"])

    # Sanity gates (adult resting).
    if pr is not None and not (100.0 <= pr <= 300.0):
        pr = None
    if qrs is not None and not (40.0 <= qrs <= 160.0):
        qrs = None
    if qt is not None and not (220.0 <= qt <= 460.0):
        qt = None

    qtc = qt / np.sqrt(rr_sec) if (qt is not None and rr_sec and rr_sec > 0) else None
    if qtc is not None and not (280.0 <= qtc <= 520.0):
        qtc = None
    return dict(pr=pr, qrs=qrs, qt=qt, qtc=qtc)


# --------------------------------------------------------------------------
# Sample sources
# --------------------------------------------------------------------------
class SerialSource:
    """Drains whole lines waiting in the serial buffer and parses them
    into millivolts (firmware sends integer tenths-of-mV)."""

    def __init__(self, port, baud):
        import serial  # imported lazily so --simulate needs no pyserial
        self.ser = serial.Serial(port, baud, timeout=1)

    def read(self):
        out = []
        while self.ser.in_waiting:
            line = self.ser.readline().decode(errors="ignore").strip()
            if not line:
                continue
            try:
                out.append(int(line) * MV_PER_UNIT)
            except ValueError:
                continue  # skip corrupted / partial lines
        return out

    def close(self):
        self.ser.close()


class SimSource:
    """Synthesises a realistic ECG (P-QRS-T built from Gaussians) at `fs`,
    in real time, plus baseline wander, mains hum and white noise. Lets you
    validate filtering + R-R detection + the plot with no hardware."""

    def __init__(self, fs, bpm=72.0, mains_hz=50.0):
        self.fs = fs
        self.rr = 60.0 / bpm
        self.mains_hz = mains_hz
        self.t = 0.0
        self.beat_t = 0.0
        self.last = time.perf_counter()

    @staticmethod
    def _beat(phase):
        # phase in seconds since the last R-R start; a ~0.8 s template.
        def g(center, amp, width):
            return amp * np.exp(-((phase - center) ** 2) / (2 * width ** 2))
        return (g(0.20, 0.10, 0.025) +   # P
                g(0.38, -0.15, 0.010) +  # Q
                g(0.40, 1.00, 0.011) +   # R
                g(0.42, -0.25, 0.011) +  # S
                g(0.60, 0.30, 0.040))    # T

    def read(self):
        now = time.perf_counter()
        n = int((now - self.last) * self.fs)
        if n <= 0:
            return []
        self.last += n / self.fs
        out = []
        for _ in range(n):
            ecg = self._beat(self.beat_t) * 1.2  # ~1.2 mV R-wave
            noise = 0.02 * np.random.randn()
            hum = 0.03 * np.sin(2 * np.pi * self.mains_hz * self.t)
            wander = 0.05 * np.sin(2 * np.pi * 0.25 * self.t)
            out.append(1650.0 + (ecg + noise + hum + wander))  # ~1.65 V bias
            self.t += 1.0 / self.fs
            self.beat_t += 1.0 / self.fs
            if self.beat_t >= self.rr:
                self.beat_t -= self.rr
        return out

    def close(self):
        pass


# --------------------------------------------------------------------------
# Plotter
# --------------------------------------------------------------------------
class ECGPlotter:
    def __init__(self, source, seconds, mains_hz, raw_only):
        self.source = source
        self.raw_only = raw_only
        self.window = int(seconds * FS)
        self.t_axis = np.arange(self.window) / FS  # seconds, fixed grid

        # NaN-filled so the plot shows empty grid until real data arrives
        # (the original prefilled zeros, which faked a flat trace and
        # corrupted the first BPM estimates).
        self.raw_buf = deque([np.nan] * self.window, maxlen=self.window)
        self.filt_buf = deque([np.nan] * self.window, maxlen=self.window)

        if not raw_only:
            (self.bp_sos, self._bp_zi_unit,
             self.notch_b, self.notch_a, self._notch_zi_unit) = build_filters(mains_hz)
            self.bp_zi = None
            self.notch_zi = None
            self.initialized = False
            self.polarity = 1.0  # flipped to -1 if QRS is predominantly negative

        self._build_figure(seconds)

    # ---- figure / ECG grid ------------------------------------------------
    def _build_figure(self, seconds):
        if self.raw_only:
            self.fig, ax = plt.subplots(1, 1, figsize=(16, 6))
            self.axes = [ax]
            self.line_raw, = ax.plot(self.t_axis, list(self.raw_buf), lw=0.8, color="tab:gray")
            ax.set_ylabel("Raw signal (mV)")
            ax.grid(True, alpha=0.3)
            ax.set_xlabel(f"Time (s)   -   {seconds:.0f} s window @ {FS:.0f} Hz")
            ax.set_xlim(0, seconds)
            self.fig.tight_layout()
            return

        self.fig = plt.figure(figsize=(16, 9))
        self.fig.patch.set_facecolor("white")
        # Rows: raw rhythm, filtered rhythm strip, representative beat.
        gs = self.fig.add_gridspec(3, 1, height_ratios=[1.6, 1.8, 2.2],
                                   left=0.07, right=0.985, top=0.80, bottom=0.07, hspace=0.35)
        self.ax_raw = self.fig.add_subplot(gs[0])
        self.ax_filt = self.fig.add_subplot(gs[1], sharex=self.ax_raw)
        self.ax_beat = self.fig.add_subplot(gs[2])
        self.axes = [self.ax_raw, self.ax_filt, self.ax_beat]

        self.line_raw, = self.ax_raw.plot(self.t_axis, list(self.raw_buf), lw=0.8, color="tab:gray")
        self.ax_raw.set_ylabel("Raw (mV)")
        self.ax_raw.set_title("Raw signal", loc="left", fontsize=9, color="0.4")
        self.ax_raw.grid(True, alpha=0.3)

        self.line_filt, = self.ax_filt.plot(self.t_axis, list(self.filt_buf), lw=1.1, color="k")
        self.r_marks, = self.ax_filt.plot([], [], "o", color="tab:red", ms=4)
        self.ax_filt.set_ylabel("Filtered (mV)")
        self.ax_filt.set_title("Rhythm strip (R-peaks marked)", loc="left", fontsize=9, color="0.4")
        self.ax_filt.set_xlabel(f"Time (s)   -   {seconds:.0f} s @ {FS:.0f} Hz")
        self._apply_ecg_grid(self.ax_filt)

        for ax in (self.ax_raw, self.ax_filt):
            ax.set_xlim(0, seconds)
            ax.xaxis.set_major_locator(MultipleLocator(0.2))
            ax.xaxis.set_minor_locator(MultipleLocator(0.04))
            ax.xaxis.set_major_formatter(
                FuncFormatter(lambda v, _pos: f"{v:.0f}" if abs(v - round(v)) < 1e-6 else ""))

        # Representative-beat panel (P-Q-R-S-T-U labelled).
        self.beat_line, = self.ax_beat.plot([], [], lw=1.6, color="k")
        self.ax_beat.set_title("Representative beat (median of recent beats)",
                               loc="left", fontsize=9, color="0.4")
        self.ax_beat.set_xlabel("Time (s)")
        self.ax_beat.set_ylabel("mV")
        self._apply_ecg_grid(self.ax_beat)
        self.ax_beat.xaxis.set_major_locator(MultipleLocator(0.2))
        self.ax_beat.xaxis.set_minor_locator(MultipleLocator(0.04))
        self._beat_artists = []  # wave labels + fiducial markers, cleared each refresh

        # Report header (clinical-style measurement block).
        self.fig.suptitle("ECG Report  -  ESP32-S3 / AD8232 (single lead, calibrated mV)",
                          x=0.07, ha="left", fontsize=14, fontweight="bold")
        self.report_text = self.fig.text(
            0.07, 0.955, "", ha="left", va="top", family="monospace",
            fontsize=10.5, color="#003366",
            bbox=dict(boxstyle="round", fc="#eef4ff", ec="#9db8e0"))
        self.interp_text = self.fig.text(
            0.995, 0.955, "", ha="right", va="top", family="monospace",
            fontsize=10.5, fontweight="bold", color="#004d00")

        self._frame = 0
        self._last_metrics_frame = -999

    @staticmethod
    def _apply_ecg_grid(ax):
        """Standard ECG-paper look: 0.2 s major / 0.04 s minor time squares.
        Time is physically accurate. The amplitude grid is set dynamically in
        `_set_amplitude_grid` because the AD8232 *output* swing (its own fixed
        gain) can be volts, not the ~1 mV of a raw lead - a fixed 0.1 mV grid
        would demand tens of thousands of gridlines and blow up the locator."""
        ax.xaxis.set_major_locator(MultipleLocator(0.2))
        ax.xaxis.set_minor_locator(MultipleLocator(0.04))
        ax.grid(which="major", color="#e57373", lw=0.8, alpha=0.7)
        ax.grid(which="minor", color="#f4c9c9", lw=0.5, alpha=0.6)
        ax.set_axisbelow(True)

    @staticmethod
    def _nice_step(span, target_divisions=6):
        """Pick a 1/2/5 x 10^k 'nice' major step so `span` shows roughly
        `target_divisions` major squares."""
        if span <= 0:
            return 0.5
        raw = span / target_divisions
        mag = 10.0 ** np.floor(np.log10(raw))
        for m in (1.0, 2.0, 5.0, 10.0):
            if raw <= m * mag:
                return m * mag
        return 10.0 * mag

    def _set_amplitude_grid(self, ax, lo, hi):
        """Choose an amplitude grid that keeps the ECG-paper ratio (5 minor
        squares per major) but adapts to the real signal amplitude, then snap
        the y-limits to the major step."""
        major = self._nice_step(hi - lo)
        lo = np.floor(lo / major) * major
        hi = np.ceil(hi / major) * major
        ax.set_ylim(lo, hi)
        ax.yaxis.set_major_locator(MultipleLocator(major))
        ax.yaxis.set_minor_locator(MultipleLocator(major / 5.0))

    # ---- filtering --------------------------------------------------------
    def _filter_batch(self, values):
        arr = np.asarray(values, dtype=float)
        if not self.initialized:
            # Scale the bandpass state by the raw first sample so it starts
            # at steady state (bandpass output for a DC input settles to 0).
            self.bp_zi = self._bp_zi_unit * arr[0]
            band, self.bp_zi = sosfilt(self.bp_sos, arr, zi=self.bp_zi)
            # The notch runs on the bandpassed signal, so scale ITS state by
            # the bandpass output's first sample (~0), not the raw ~1650 mV -
            # scaling by the raw value was injecting a large false transient.
            self.notch_zi = self._notch_zi_unit * band[0]
            notched, self.notch_zi = lfilter(self.notch_b, self.notch_a, band, zi=self.notch_zi)
            self.initialized = True
            return notched
        band, self.bp_zi = sosfilt(self.bp_sos, arr, zi=self.bp_zi)
        notched, self.notch_zi = lfilter(self.notch_b, self.notch_a, band, zi=self.notch_zi)
        return notched

    # ---- signal quality ---------------------------------------------------
    def _quality_warning(self, raw_valid):
        if raw_valid.size < FS:
            return ""
        recent = raw_valid[-int(FS):]
        # Flat / railed -> almost certainly poor electrode contact.
        if np.ptp(recent) < 0.5:                      # essentially no swing in 1 s
            return "  [CHECK ELECTRODES: flat signal]"
        if np.mean((recent < 30) | (recent > 3270)) > 0.2:
            return "  [SIGNAL RAILED: adjust contact]"
        return ""

    # ---- report + representative beat -------------------------------------
    def _refresh_report(self, disp, valid_mask, r_idx, raw_valid):
        bpm, rmssd, rr = heart_rate_from_peaks(r_idx, FS)
        rr_mean = float(np.mean(rr)) if rr.size else None

        fid = delineate_beat(disp, r_idx, FS, rr_sec=rr_mean)
        iv = clinical_intervals(fid, rr_mean) if (fid and rr_mean) else \
            dict(pr=None, qrs=None, qt=None, qtc=None)

        def f(x, u="ms", w=6):
            return (f"{x:{w}.0f} {u}" if x is not None else f"{'--':>6} {u}")

        rr_ms = rr_mean * 1000.0 if rr_mean else None
        lines = [
            f"HR      : {bpm:5.0f} bpm" if bpm else "HR      :   --  bpm",
            f"R-R     : {f(rr_ms)}",
            f"PR      : {f(iv['pr'])}",
            f"QRS     : {f(iv['qrs'])}",
            f"QT/QTc  : {f(iv['qt'],'')}/{f(iv['qtc'])}",
            f"HRV RMSSD: {f(rmssd)}" if rmssd is not None else "HRV RMSSD:   --  ms",
        ]
        self.report_text.set_text("\n".join(lines))
        self.interp_text.set_text(self._interpretation(bpm, rr, iv) +
                                  self._quality_warning(raw_valid))

        if fid is not None:
            self._draw_beat(fid)

    @staticmethod
    def _interpretation(bpm, rr, iv):
        """Very small rule-based read-out (rate + regularity + interval flags).
        NOT a diagnosis - just mirrors the summary line clinical carts print."""
        if bpm is None:
            return "Acquiring..."
        parts = []
        if bpm < 60:
            parts.append("Bradycardia")
        elif bpm > 100:
            parts.append("Tachycardia")
        else:
            parts.append("Normal rate")
        # Regularity from R-R coefficient of variation.
        if rr.size >= 3:
            cv = np.std(rr) / np.mean(rr)
            parts.append("regular" if cv < 0.12 else "irregular")
        flags = []
        if iv["pr"] and iv["pr"] > 200:
            flags.append("long PR")
        if iv["qrs"] and iv["qrs"] > 120:
            flags.append("wide QRS")
        if iv["qtc"] and iv["qtc"] > 460:
            flags.append("long QTc")
        line = ", ".join(parts)
        if flags:
            line += "  |  " + ", ".join(flags)
        return line

    def _draw_beat(self, fid):
        for a in self._beat_artists:
            a.remove()
        self._beat_artists = []

        tmpl = fid["template"]
        dt = fid["dt"]
        t = np.arange(len(tmpl)) * dt
        self.beat_line.set_data(t, tmpl)
        self.ax_beat.set_xlim(0, t[-1])
        base = fid["baseline"]
        span = max(np.ptp(tmpl), 0.5)
        # Extra headroom top/bottom so the P/R/T labels aren't clipped.
        self._set_amplitude_grid(self.ax_beat, base - span * 0.9, base + span * 1.05)
        self.ax_beat.set_xlim(0, t[-1])

        # Baseline (isoelectric) reference line.
        bl = self.ax_beat.axhline(base, color="0.6", lw=0.7, ls="--")
        self._beat_artists.append(bl)

        colors = dict(P="tab:green", Q="tab:purple", R="tab:red",
                      S="tab:purple", T="tab:orange", U="tab:brown")
        for name in ("P", "Q", "R", "S", "T", "U"):
            i = fid.get(name)
            if i is None:
                continue
            y = tmpl[i]
            m, = self.ax_beat.plot(t[i], y, "o", color=colors[name], ms=5)
            off = 0.06 * span if (y >= base) else -0.06 * span
            va = "bottom" if y >= base else "top"
            lbl = self.ax_beat.annotate(
                name, (t[i], y), xytext=(t[i], y + off), ha="center", va=va,
                fontsize=11, fontweight="bold", color=colors[name])
            self._beat_artists += [m, lbl]

    # ---- animation update -------------------------------------------------
    def update(self, _frame):
        values = self.source.read()
        for v in values:
            self.raw_buf.append(v)
        if not self.raw_only and values:
            for fv in self._filter_batch(values):
                self.filt_buf.append(fv)

        self.line_raw.set_ydata(self.raw_buf)
        raw_arr = np.asarray(self.raw_buf, dtype=float)
        raw_valid = raw_arr[~np.isnan(raw_arr)]
        if raw_valid.size:
            lo, hi = raw_valid.min(), raw_valid.max()
            m = max((hi - lo) * 0.1, 1.0)
            self.axes[0].set_ylim(lo - m, hi + m)

        if self.raw_only:
            return (self.line_raw,)

        self._frame += 1
        filt_arr = np.asarray(self.filt_buf, dtype=float)
        valid_mask = ~np.isnan(filt_arr)
        if valid_mask.sum() > 5:
            v = filt_arr[valid_mask]
            center = np.median(v)

            # Auto-detect QRS polarity: if the dominant deflection is downward
            # (e.g. swapped LA/RA electrodes or an inverted lead), flip the
            # trace so R-waves point UP, as on a standard ECG. Hysteresis
            # (1.2x) stops the display flip-flopping on borderline signals.
            up = np.percentile(v, 99.5) - center
            down = center - np.percentile(v, 0.5)
            if down > up * 1.2:
                self.polarity = -1.0
            elif up > down * 1.2:
                self.polarity = 1.0

            disp = filt_arr * self.polarity
            self.line_filt.set_ydata(disp)
            dcenter = center * self.polarity

            dev = np.percentile(np.abs(disp[valid_mask] - dcenter), 98)
            half = max(dev * 1.4, 0.3)
            self._set_amplitude_grid(self.ax_filt, dcenter - half, dcenter + half)

            # R-peak detection on the polarity-corrected (R-upright) window.
            seg = np.where(valid_mask, disp, 0.0)
            first_valid = int(np.argmax(valid_mask))
            r_idx = detect_r_peaks(seg[first_valid:], FS) + first_valid
            r_idx = r_idx[valid_mask[r_idx]]
            self.r_marks.set_data(self.t_axis[r_idx], disp[r_idx])

            # Metrics + beat delineation are heavier; refresh ~2x/second.
            if self._frame - self._last_metrics_frame >= 15:
                self._last_metrics_frame = self._frame
                self._refresh_report(disp, valid_mask, r_idx, raw_valid)

        return (self.line_raw, self.line_filt, self.r_marks, self.beat_line)

    def run(self):
        self._ani = animation.FuncAnimation(
            self.fig, self.update, interval=30, blit=False, cache_frame_data=False)
        try:
            plt.show()
        finally:
            self.source.close()


# --------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(description="Live ECG plotter for ESP32-S3 + AD8232")
    p.add_argument("--port", help="Serial port, e.g. COM5 or /dev/ttyUSB0")
    p.add_argument("--baud", type=int, default=115200, help="Baud rate (default 115200)")
    p.add_argument("--seconds", type=float, default=6.0,
                   help="Seconds of ECG visible in the plot (default 6). "
                        "Smaller = wider/zoomed-in beats; larger = longer window.")
    p.add_argument("--mains", type=float, default=50.0, choices=[50.0, 60.0],
                   help="Mains hum frequency to notch out (default 50)")
    p.add_argument("--raw-only", action="store_true",
                   help="Skip filtering / detection, plot raw values only")
    p.add_argument("--simulate", action="store_true",
                   help="Generate a synthetic ECG (no hardware needed)")
    p.add_argument("--bpm", type=float, default=72.0, help="Heart rate for --simulate")
    args = p.parse_args()

    if args.simulate:
        source = SimSource(FS, bpm=args.bpm, mains_hz=args.mains)
    else:
        if not args.port:
            p.error("--port is required unless --simulate is used")
        try:
            source = SerialSource(args.port, args.baud)
        except Exception as e:  # serial.SerialException or ImportError
            print(f"Could not open serial port '{args.port}': {e}", file=sys.stderr)
            sys.exit(1)

    ECGPlotter(source, args.seconds, args.mains, args.raw_only).run()


if __name__ == "__main__":
    main()
